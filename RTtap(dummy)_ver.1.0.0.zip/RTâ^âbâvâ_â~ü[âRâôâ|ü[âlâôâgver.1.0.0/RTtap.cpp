// -*- C++ -*-
/*!
 * @file  RTtap.cpp
 * @brief RTtap
 * @date $Date$
 *
 * $Id$
 */

#include "RTtap.h"
#include <iostream>
#include <string>

using namespace std;

string first;

// Module specification
// <rtc-template block="module_spec">
static const char* rttap_spec[] =
  {
    "implementation_id", "RTtap",
    "type_name",         "RTtap",
    "description",       "RTtap",
    "version",           "1.0.0",
    "vendor",            "Keisuke TANAKA",
    "category",          "Category",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "10",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
RTtap::RTtap(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_opeIn("ope", m_ope),
    m_devinfoIn("devinfo", m_devinfo),
    m_updateOut("update", m_update),
    m_requestOut("request", m_request)

    // </rtc-template>
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  registerInPort("ope", m_opeIn);
  registerInPort("devinfo", m_devinfoIn);
  
  // Set OutPort buffer
  registerOutPort("update", m_updateOut);
  registerOutPort("request", m_requestOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

}

/*!
 * @brief destructor
 */
RTtap::~RTtap()
{
}


RTC::ReturnCode_t RTtap::onInitialize()
{
	first = "1";

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t RTtap::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RTtap::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RTtap::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RTtap::onActivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RTtap::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t RTtap::onExecute(RTC::UniqueId ec_id)
{
	string memo = "";
	string memo2 = "";
	string memo3 = "";
	string no = "";
	string num = "";
	string ope = "";
	unsigned int loc = 0;

	if (first == "1")
	{
		memo = "910";

		m_request.data = memo.c_str(); 
		cout << m_request.data << endl;
		m_requestOut.write();

		first = "0";
	}

	if (m_opeIn.isNew())
    {
		m_opeIn.read();
		memo = m_ope.data;

		cout << "Received: " << memo << endl;

		m_update.data = memo.c_str(); 
		cout << m_update.data << endl;
		m_updateOut.write();
	}

	if (m_devinfoIn.isNew())
	{
		m_devinfoIn.read();
		memo = m_devinfo.data;
		cout << "Received: " << memo << endl;

		unsigned int loc1 = 0;
		unsigned int loc2 = 0;

		while (memo.size() != 0)
		{
			loc1 = memo.find(".", loc1);						// .�̈ʒu
			memo2 = memo.substr(0, loc1);						// .�̑O�܂�
//			cout << memo2 << endl;

			loc2 = memo.find(";", loc1);						// :�̈ʒu
			memo3 = memo.substr(loc1 + 1, loc2 - loc1 - 1);		// .�̌ォ��:�̑O�܂�
//			cout << memo3 << endl;
			memo = memo.substr(loc2 - loc1 + 3);
//			cout << memo << endl;

			if (memo2 == "no")
			{
				no = memo3;
//				cout << no << endl;
			}

			else if (memo2 == "o1" && memo3.size() != 0)
			{
				ope = memo3;
//				cout << ope << endl;

				memo = no;
				memo += ".1";
				memo += ope;
			}

			else if (memo2 == "o2" && memo3.size() != 0)
			{
				ope = memo3;
//				cout << ope << endl;

				memo = no;
				memo += ".2";
				memo += ope;
			}

			else if (memo2 == "o3" && memo3.size() != 0)
			{
				ope = memo3;
//				cout << ope << endl;

				memo = no;
				memo += ".3";
				memo += ope;
			}
		}
	}

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t RTtap::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RTtap::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RTtap::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RTtap::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RTtap::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void RTtapInit(RTC::Manager* manager)
  {
    coil::Properties profile(rttap_spec);
    manager->registerFactory(profile,
                             RTC::Create<RTtap>,
                             RTC::Delete<RTtap>);
  }
  
};