// -*- C++ -*-
/*!
 * @file  DB.cpp
 * @brief DB
 * @date $Date$
 *
 * $Id$
 */

#include "DB.h"
#include <fstream>
#include <string.h>
#include <iostream>
#include <string>
#include <stdio.h>
#include <windows.h>

using namespace std;

string qr = "";
string frag = "A";

struct db
{
	string no;

	string app1;
	string app2;
	string app3;

	string ope1;
	string ope2;
	string ope3;
}info1;

// Module specification
// <rtc-template block="module_spec">
static const char* db_spec[] =
  {
    "implementation_id", "DB",
    "type_name",         "DB",
    "description",       "DB",
    "version",           "1.0.0",
    "vendor",            "Keisuke TANAKA",
    "category",          "Category",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "10",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
DB::DB(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_qrIn("qr", m_qr),
    m_applianceIn("appliance", m_appliance),
    m_deviceIn("device", m_device),
    m_requestIn("request", m_request),
    m_appinfoOut("appinfo", m_appinfo),
    m_devinfoOut("devinfo", m_devinfo)

    // </rtc-template>
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  registerInPort("qr", m_qrIn);
  registerInPort("appliance", m_applianceIn);
  registerInPort("device", m_deviceIn);
  registerInPort("request", m_requestIn);
  
  // Set OutPort buffer
  registerOutPort("appinfo", m_appinfoOut);
  registerOutPort("devinfo", m_devinfoOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

}

/*!
 * @brief destructor
 */
DB::~DB()
{
}



RTC::ReturnCode_t DB::onInitialize()
{
  return RTC::RTC_OK;
}


RTC::ReturnCode_t DB::onFinalize()
{
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t DB::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DB::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t DB::onActivated(RTC::UniqueId ec_id)
{
	info1.no = "910";
	frag = "A";

	ifstream filein;
	filein.open ("/DBcompinfo.txt");

	if( filein.is_open () ==0 )
	{
		cout << "Error: �t�@�C�����I�[�v���ł��܂���" << endl;
	}

	else
	{
		string copy = "";
		string copy2 = "";										// �U���������ʗp
		string copy3 = "";										// �f�[�^�R�s�[�p
		unsigned int loc1 = 0;
		unsigned int loc2 = 0;

		filein >> copy;
		filein.close (); 
		cout << copy << endl;									// ex. no.910;a1.mi;a2.;a3.;o1.;o2.;o3.;

		while (copy.size() != 0)
		{
			loc1 = copy.find(".", loc1);						// .�̈ʒu
			copy2 = copy.substr(0, loc1);						// .�̑O�܂�
//			cout << copy2 << endl;

			loc2 = copy.find(";", loc1);						// :�̈ʒu
			copy3 = copy.substr(loc1 + 1, loc2 - loc1 - 1);		// .�̌ォ��:�̑O�܂�
//			cout << copy3 << endl;
			copy = copy.substr(loc2 - loc1 + 3);
//			cout << copy << endl;

			if (copy2 == "no")
			{
				info1.no = copy3;
//				cout << info1.no << endl;
			}

			else if (copy2 == "a1" && copy3.size() != 0)
			{
				info1.app1 = copy3;
//				cout << info1.app1 << endl;
			}

			else if (copy2 == "a2" && copy3.size() != 0)
			{
				info1.app2 = copy3;
//				cout << info1.app2 << endl;
			}

			else if (copy2 == "a3" && copy3.size() != 0)
			{
				info1.app3 = copy3;
//				cout << info1.app3 << endl;
			}

			else if (copy2 == "o1" && copy3.size() != 0)
			{
				info1.ope1 = copy3;
//				cout << info1.ope1 << endl;
			}

			else if (copy2 == "o2" && copy3.size() != 0)
			{
				info1.ope2 = copy3;
//				cout << info1.ope2 << endl;
			}

			else if (copy2 == "o3" && copy3.size() != 0)
			{
				info1.ope3 = copy3;
//				cout << info1.ope3 << endl;
			}
		}
	}

  return RTC::RTC_OK;
}


/*
RTC::ReturnCode_t DB::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t DB::onExecute(RTC::UniqueId ec_id)
{
	cout << "no: " << info1.no << endl;
	cout << "a1: " << info1.app1 << endl;
	cout << "a2: " << info1.app2 << endl;
	cout << "a3: " << info1.app3 << endl;
	cout << "o1: " << info1.ope1 << endl;
	cout << "o2: " << info1.ope2 << endl;
	cout << "o3: " << info1.ope3 << endl;

	string memo = "";
	string memo2 = "";
	string memo3 = "";
	unsigned int loc = 0;

	if (m_qrIn.isNew())
    {
		m_qrIn.read();
		qr = m_qr.data;

		cout << "Received: " << qr << endl;

		if (qr == info1.no && frag == "A")
		{
			memo = "";
			memo += info1.app1;
//			memo += ".";
			memo += info1.ope1;
			memo += ".";
			memo += info1.app2;
//			memo += ".";
			memo += info1.ope2;
			memo += ".";
			memo += info1.app3;
//			memo += ".";
			memo += info1.ope3;

			m_appinfo.data = memo.c_str();
			cout << "Output: " << m_appinfo.data << endl;
			m_appinfoOut.write();

			frag = "D";
		}
	}

	if (m_applianceIn.isNew())
    {
		m_applianceIn.read();
		memo = m_appliance.data;

		cout << "Received: " << memo << endl;

		loc = memo.find(".", 0);					// .�̈ʒu
		memo2 = memo.substr(0, loc);				// .��1�O�܂�
//		cout << memo2 << endl;

		if (memo2 == info1.no)
		{
			loc = memo.find(".", loc + 1);			// .�̎�����
			memo2 = memo.substr(loc - 1, 1);		// .�̎���1����
//			cout << memo2 << endl;
			memo3 = memo.substr(loc + 1);		// .�̎���.�̌ォ��
//			cout << memo2 << endl;
			
			if (memo2 == "1" && memo3 != "no_change")
			{
				info1.app1 = memo3;
			}

			else if (memo2 == "2" && memo3 != "no_change")
			{
				info1.app2 = memo3;
			}

			else if (memo2 == "3" && memo3 != "no_change")
			{
				info1.app3 = memo3;
			}
		}

		memo = "";
		memo += info1.app1;
//		memo += ".";
		memo += info1.ope1;
		memo += ".";
		memo += info1.app2;
//		memo += ".";
		memo += info1.ope2;
		memo += ".";
		memo += info1.app3;
//		memo += ".";
		memo += info1.ope3;

		m_appinfo.data = memo.c_str();
		cout << "Output: " << m_appinfo.data << endl;
		m_appinfoOut.write();
	}

	if (m_deviceIn.isNew())
    {
		m_deviceIn.read();
		memo = m_device.data;

		cout << "Received: " << memo << endl;

		loc = memo.find(".", 0);					// .�̈ʒu
		memo2 = memo.substr(0, loc);				// .��1�O�܂�
		
		if (memo2 == info1.no)
		{
			loc = memo.find(".", loc + 1);			// .�̎�����
			memo2 = memo.substr(loc - 1, 1);		// .�̎���1����
			
			if (memo2 == "1")
			{
				memo2 = memo.substr(loc + 1);		// .�̎���.�̌ォ��
				info1.ope1 = memo2;
			}

			else if (memo2 == "2")
			{
				memo2 = memo.substr(loc + 1);		// .�̎���.�̌ォ��
				info1.ope2 = memo2;
			}

			else if (memo2 == "3")
			{
				memo2 = memo.substr(loc + 1);		// .�̎���.�̌ォ��
				info1.ope3 = memo2;
			}
		}
		
		memo = "";
		memo += info1.app1;
//		memo += ".";
		memo += info1.ope1;
		memo += ".";
		memo += info1.app2;
//		memo += ".";
		memo += info1.ope2;
		memo += ".";
		memo += info1.app3;
//		memo += ".";
		memo += info1.ope3;

		m_appinfo.data = memo.c_str();
		cout << "Output: " << m_appinfo.data << endl;
		m_appinfoOut.write();
	}

	if (m_requestIn.isNew())
    {
		m_requestIn.read();
		memo = m_request.data;

		cout << "Received: " << memo << endl;

		if (memo == info1.no)
		{
			memo = "no.";
			memo += info1.no;
			memo += ";o1.";
			memo += info1.ope1;
			memo += ";o2.";
			memo += info1.ope2;
			memo += ";o3.";
			memo += info1.ope3;

			m_devinfo.data = memo.c_str();
			cout << "Output: " << m_devinfo.data << endl;
			m_devinfoOut.write();
		}
	}

	ofstream fileout;
	fileout.open("/DBcompinfo.txt");		// �o�̓t�@�C�����I�[�v��

	if (!fileout)							// �G���[����
	{
		cout << "Error: �t�@�C�����I�[�v���ł��܂���" << endl;
	}

	else
	{
		fileout << "no." << info1.no << ';';
		fileout << "a1." << info1.app1 << ';';
		fileout << "a2." << info1.app2 << ';';
		fileout << "a3." << info1.app3 << ';';
		fileout << "o1." << info1.ope1 << ';';
		fileout << "o2." << info1.ope2 << ';';
		fileout << "o3." << info1.ope3 << ';';
	}

	fileout.close();

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t DB::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DB::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DB::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DB::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DB::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void DBInit(RTC::Manager* manager)
  {
    coil::Properties profile(db_spec);
    manager->registerFactory(profile,
                             RTC::Create<DB>,
                             RTC::Delete<DB>);
  }
  
};


