// -*- C++ -*-
/*!
 * @file  art.cpp
 * @brief ARToolkit image capture component
 * @date $Date$
 *
 * $Id$
 */

/*******************************************************************************************/
// ���R���|�[�l���g�͈ȉ��̃T�C�g�Ō��J����Ă���ARToolKit�R���|�[�l���g����ɍ쐬���܂��� //
//                                                                                         //
// http://www.openrtm.org/openrtm/ja/project/ARToolkit_DCI_AIST                            //
/*******************************************************************************************/

#include "art.h"
#include <iostream>
using namespace std;

string app1 = "";
string app2 = "";
string app3 = "";
char file1[30];
char file2[30];
char file3[30];
string f1 = "";
string f2 = "";
string f3 = "";
string frag = "";
int centerX;
int centerY;
int dir;

// Module specification
// <rtc-template block="module_spec">
static const char* art_spec[] =
  {
    "implementation_id", "art",
    "type_name",         "ARToolKit-RTC",
    "description",       "Augmented Reality RT-Component",
    "version",           "1.0.0",
    "vendor",            "JANG MINHO, LEE HYUNDEOK",
    "category",          "example",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "100.0",

		// Configuration variables
		"conf.default.FILE Camera_Parameter", "camera/camera_para.dat",
	    "conf.default.FILE Marker", "marker/patt.ar",
		"conf.default.Marker_Check Monochrome(0-255)", "100",
		""
  };
// </rtc-template>

// ============================================================================
//	Global variables
// ============================================================================
// �O���[�o���ϐ�

std::string	cparam_name;		// �J�����p�����[�^�t�@�C��
std::string	patt_name;			// �p�^�[���t�@�C��
int		thresh;					// 2�l����臒l
int		patt_id;				// �p�^�[����ID

ARParam	cparam;					// �J�����p�����[�^
ARParam	wparam;					// �J�����p�����[�^�i��Ɨp�ϐ��j

double	patt_trans[3][4];				// ���W�ϊ��s��
double	patt_center[2]	= { 0.0, 0.0 };	// �p�^�[���̒��S���W
double	patt_width		= 42.0;			// �p�^�[���̃T�C�Y�i�P�ʁFmm�j

// ���̓C���[�W��Temp
int m_in_height = 0;					// ���̓C���[�W��TempHeight
int m_in_width = 0;						// ���̓C���[�W��TempWidth

// flag
bool ARMainLoopStopFlag = FALSE;
bool paramInitFlag = FALSE;
bool scale_all_flag = FALSE;

// Frame Buffer Objext var
GLuint texture_name;
GLuint renderbuffer_name;
GLuint framebuffer_name;

// image global var
ARUint8*	ar_image;
IplImage* opencv_img_send_tmp;
IplImage* opencv_img_send_mono_tmp;


/* �e�N�X�`���E�}�b�s���O */	// �ǉ�
GLuint			listid1;					// �f�B�X�v���C�E���X�g��ID
GLuint			listid2;					// �f�B�X�v���C�E���X�g��ID
GLuint			listid3;					// �f�B�X�v���C�E���X�g��ID
GLuint			texname1[6];				// �e�N�X�`���I�u�W�F�N�g�̖��O
unsigned char	dat[128*128*3];				// �s�N�Z���f�[�^
GLubyte			teximg[128][128][4];		// �e�N�X�`���f�[�^
GLuint			texname2[6];				// �e�N�X�`���I�u�W�F�N�g�̖��O
GLuint			texname3[6];				// �e�N�X�`���I�u�W�F�N�g�̖��O

//////////////// �C���[�W�ϐ��̕ϊ��菇 ////////////////////////
//
//---- onExecute() ----
// m_in.pixels[0] 
// -> opencv_image(cv�`��p) 
// -> opencv_marker_image(cv���o�p) -> ar_image(ar���o�p)

//---- AR_MainLoop() ----
// ar_image(ar���o�p)
//			1)	ar_image(2D camera image) -> buffer 
//			2)	ar_image(2D camera image) -> �p�^�[���F�� -> 3D object -> buffer
// buffer
// -> opencv_img_send_tmp(cv���o�p) 

//---- onExecute() ----
// opencv_img_send_tmp(cv���o�p) 
// -> opencv_img_send(cv�`��p) 
// -> m_out.pixels[0]
/////////////////////////////////////////////////////////////////

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
art::art(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
		m_inIn("Camera_Image_IN", m_in),
	    m_appinfoIn("appinfo", m_appinfo),
		m_settingIn("setting", m_setting),
		m_outOut("AR_Rendering_Image_OUT", m_out),
		m_out_monoOut("Marker_Detect_Mono_OUT", m_out_mono),
	    m_centerXOut("centerX", m_centerX),
		m_centerYOut("centerY", m_centerY),
		m_dirOut("dir", m_dir),
    dummy(0)

    // </rtc-template>
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  registerInPort("Camera_Image_IN", m_inIn);
  registerInPort("appinfo", m_appinfoIn);
  registerInPort("setting", m_settingIn);
  registerOutPort("AR_Rendering_Image_OUT", m_outOut);
  registerOutPort("Marker_Detect_Mono_OUT", m_out_monoOut);
  registerOutPort("centerX", m_centerXOut);
  registerOutPort("centerY", m_centerYOut);
  registerOutPort("dir", m_dirOut);

	// Set OutPort buffer
   
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

}

/*!
 * @brief destructor
 */
art::~art()
{
}



RTC::ReturnCode_t art::onInitialize()
{
	bindParameter("FILE Camera_Parameter", cfg_cparam_name, "camera/camera_para.dat");
	bindParameter("FILE Marker", cfg_patt_name,   "marker/patt.ar");
	bindParameter("Marker_Check Monochrome(0-255)", cfg_thresh,   "100");

	arDebug = 1;

	string s1 = "Texture\\yomi.bmp";
	string s2 = "Texture\\komi.bmp";
	string s3 = "Texture\\tyu.bmp";
	strcpy(file1, s1.c_str());
	strcpy(file2, s2.c_str());
	strcpy(file3, s3.c_str());

  return RTC::RTC_OK;
}


/*
RTC::ReturnCode_t art::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t art::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t art::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t art::onActivated(RTC::UniqueId ec_id)
{
	m_in_height = 0;
	m_in_width = 0;

	ar_image = NULL;
	opencv_image						= NULL;		//cv�`��p
	opencv_marker_image					= NULL;		//cv���o�p
	opencv_img_send_tmp					= NULL;		//cv���o�p
	opencv_img_send_mono_tmp			= NULL;
	opencv_img_send						= NULL;		//cv�`��p
	opencv_img_send_mono				= NULL;

	if( 0 == strcmp(patt_name.c_str(), cfg_patt_name.c_str()) )
	{
		patt_id = arLoadPatt(patt_name.c_str());
	}

	ARMainLoopStopFlag = FALSE;

  return RTC::RTC_OK;
}


RTC::ReturnCode_t art::onDeactivated(RTC::UniqueId ec_id)
{
	ARMainLoopStopFlag = TRUE;
	arUtilSleep(500);

	ar_image = NULL;
	cvReleaseImage(&opencv_marker_image);
	cvReleaseImage(&opencv_image);
	cvReleaseImage(&opencv_img_send);
	cvReleaseImage(&opencv_img_send_mono);
	cvReleaseImage(&opencv_img_send_tmp);
	cvReleaseImage(&opencv_img_send_mono_tmp);

	arFreePatt(patt_id);

  return RTC::RTC_OK;
}


RTC::ReturnCode_t art::onExecute(RTC::UniqueId ec_id)
{
	cfgCheckCparamName();
	cfgCheckPattName();
	cfgCheckThresh();

	std::string memo = "";
	std::string memo2 = "";
	f1 = "";
	f2 = "";
	f3 = "";
	unsigned int loc = 0;
	unsigned int loc2 = 0;
	unsigned int loc3 = 0;

	if (m_appinfoIn.isNew())
    {
		m_appinfoIn.read();
		memo = m_appinfo.data;

		cout << "Received: " << memo << endl;

		loc = memo.find(".", loc);
		memo2 = memo.substr(0, loc);						// 1�ڂ̉Ɠd
		app1 = memo2;
		cout << app1 << endl;

		if (app1 == "fanH")
		{
			f1 = "Texture\\fan_on.bmp";
			strcpy(file1, f1.c_str());
		}
		else if (app1 == "fanL")
		{
			f1 = "Texture\\fan_off.bmp";
			strcpy(file1, f1.c_str());
		}
		else if (app1 == "heaterH")
		{
			f1 = "Texture\\heater_on.bmp";
			strcpy(file1, f1.c_str());
		}
		else if (app1 == "heaterL")
		{
			f1 = "Texture\\heater_off.bmp";
			strcpy(file1, f1.c_str());
		}
		else if (app1 == "humidifierH")
		{
			f1 = "Texture\\humidifier_on.bmp";
			strcpy(file1, f1.c_str());
		}
		else if (app1 == "humidifierL")
		{
			f1 = "Texture\\humidifier_off.bmp";
			strcpy(file1, f1.c_str());
		}
		else if (app1 == "lightH")
		{
			f1 = "Texture\\light_on.bmp";
			strcpy(file1, f1.c_str());
		}
		else if (app1 == "lightL")
		{
			f1 = "Texture\\light_off.bmp";
			strcpy(file1, f1.c_str());
		}
		else if (app1 == "miH" || app1 == "miL")
		{
			f1 = "Texture\\mi.bmp";
			strcpy(file1, f1.c_str());
		}

		loc2 = memo.find(".", loc + 1);
		memo2 = memo.substr(loc + 1, loc2 - loc - 1);		// 2�ڂ̉Ɠd
		app2 = memo2;
		cout << app2 << endl;

		if (app2 == "fanH")
		{
			f2 = "Texture\\fan_on.bmp";
			strcpy(file2, f2.c_str());
		}
		else if (app2 == "fanL")
		{
			f2 = "Texture\\fan_off.bmp";
			strcpy(file2, f2.c_str());
		}
		else if (app2 == "heaterH")
		{
			f2 = "Texture\\heater_on.bmp";
			strcpy(file2, f2.c_str());
		}
		else if (app2 == "heaterL")
		{
			f2 = "Texture\\heater_off.bmp";
			strcpy(file2, f2.c_str());
		}
		else if (app2 == "humidifierH")
		{
			f2 = "Texture\\humidifier_on.bmp";
			strcpy(file2, f2.c_str());
		}
		else if (app2 == "humidifierL")
		{
			f2 = "Texture\\humidifier_off.bmp";
			strcpy(file2, f2.c_str());
		}
		else if (app2 == "lightH")
		{
			f2 = "Texture\\light_on.bmp";
			strcpy(file2, f2.c_str());
		}
		else if (app2 == "lightL")
		{
			f2 = "Texture\\light_off.bmp";
			strcpy(file2, f2.c_str());
		}
		else if (app2 == "miH" || app2 == "miL")
		{
			f2 = "Texture\\mi.bmp";
			strcpy(file2, f2.c_str());
		}

		loc3 = memo.size();
		memo2 = memo.substr(loc2 + 1, loc3 - loc2 - 1);				// 3�ڂ̉Ɠd
		app3 = memo2;
		cout << app3 << endl;

		if (app3 == "fanH")
		{
			f3 = "Texture\\fan_on.bmp";
			strcpy(file3, f3.c_str());
		}
		else if (app3 == "fanL")
		{
			f3 = "Texture\\fan_off.bmp";
			strcpy(file3, f3.c_str());
		}
		else if (app3 == "heaterH")
		{
			f3 = "Texture\\heater_on.bmp";
			strcpy(file3, f3.c_str());
		}
		else if (app3 == "heaterL")
		{
			f3 = "Texture\\heater_off.bmp";
			strcpy(file3, f3.c_str());
		}
		else if (app3 == "humidifierH")
		{
			f3 = "Texture\\humidifier_on.bmp";
			strcpy(file3, f3.c_str());
		}
		else if (app3 == "humidifierL")
		{
			f3 = "Texture\\humidifier_off.bmp";
			strcpy(file3, f3.c_str());
		}
		else if (app3 == "lightH")
		{
			f3 = "Texture\\light_on.bmp";
			strcpy(file3, f3.c_str());
		}else if (app3 == "lightL")
		{
			f3 = "Texture\\light_off.bmp";
			strcpy(file3, f3.c_str());
		}
		else if (app3 == "miH" || app3 == "miL")
		{
			f3 = "Texture\\mi.bmp";
			strcpy(file3, f3.c_str());
		}

		if (f1 != "" && f2 != "" && f3 != "")
		{
			frag = "all";
		}
	}

	if (m_settingIn.isNew())
	{
		m_settingIn.read();
		memo = m_setting.data;

		cout << "Received: " << memo << endl;

		if (memo == "1")
		{
			frag = "1";
		}

		else if (memo == "2")
		{
			frag = "2";
		}

		else if (memo == "3")
		{
			frag = "3";
		}
	}

	if (!m_inIn.isNew())
	{	
		return RTC::RTC_OK;
	}
	m_inIn.read();

	if (!(m_in.pixels.length() > 0))
	{
		return RTC::RTC_OK;
	}

	if(m_in_height != m_in.height || m_in_width != m_in.width || opencv_image == NULL)
	{
		ARMainLoopStopFlag = TRUE;
		arUtilSleep(500);

		m_in_height = m_in.height;
		m_in_width = m_in.width;

		if(opencv_image != NULL)
			cvReleaseImage(&opencv_image);
		if(opencv_marker_image != NULL)
			cvReleaseImage(&opencv_marker_image);
		if(opencv_img_send_tmp != NULL)
			cvReleaseImage(&opencv_img_send_tmp);
		if(opencv_img_send_mono_tmp != NULL)
			cvReleaseImage(&opencv_img_send_mono_tmp);
		if(opencv_img_send != NULL)
			cvReleaseImage(&opencv_img_send);
		if(opencv_img_send_mono != NULL)
			cvReleaseImage(&opencv_img_send_mono);

		opencv_image				= cvCreateImage(cvSize(m_in.width, m_in.height), IPL_DEPTH_8U, 3);//cv�`��p
		opencv_marker_image			= cvCreateImage(cvSize(m_in.width, m_in.height), IPL_DEPTH_8U, 4);//cv���o�p
		opencv_img_send_tmp			= cvCreateImage(cvSize(m_in.width, m_in.height), IPL_DEPTH_8U, 3);//cv���o�p
		opencv_img_send_mono_tmp	= cvCreateImage(cvSize(m_in.width, m_in.height), IPL_DEPTH_8U, 3);
		opencv_img_send				= cvCreateImage(cvSize(m_in.width, m_in.height), IPL_DEPTH_8U, 3);//cv�`��p
		opencv_img_send_mono		= cvCreateImage(cvSize(m_in.width, m_in.height), IPL_DEPTH_8U, 3);

		ARMainLoopStopFlag = FALSE;
	}

	// m_in.pixels[0] -> opencv_image (in_port -> cv�`��p)
	memcpy(opencv_image -> imageData, (void *)&(m_in.pixels[0]), m_in.pixels.length());

	// opencv_image -> opencv_marker_image (cv�`��p -> cv���o�p)(24bpp����32bpp�֕ϊ�))
	cvCvtColor(opencv_image, opencv_marker_image, CV_BGR2RGBA);

	// opencv_marker_image -> ar_image (cv���o�p -> ar���o�p)
	ar_image = (ARUint8*)(opencv_marker_image -> imageData);
	
	if(opencv_img_send_tmp -> imageData != NULL || opencv_img_send_mono_tmp != NULL)
	{
		// opencv_img_send_tmp(cv���o�p) -> opencv_img_send(cv�`��p) 
		cvCvtColor(opencv_img_send_tmp, opencv_img_send, CV_RGB2BGR);
		cvCvtColor(opencv_img_send_mono_tmp, opencv_img_send_mono, CV_RGB2BGR);

		cvFlip(opencv_img_send, opencv_img_send);
		cvFlip(opencv_img_send_mono, opencv_img_send_mono);

		// ��ʂ̃T�C�Y��������
		int len = opencv_img_send->nChannels * opencv_img_send->width * opencv_img_send->height;
		int len_mono = opencv_img_send_mono->nChannels * opencv_img_send_mono->width 
			* opencv_img_send_mono->height;

		m_out.pixels.length(len);
		m_out.width  = opencv_img_send->width;
		m_out.height = opencv_img_send->height;

		m_out_mono.pixels.length(len_mono);
		m_out_mono.width  = opencv_img_send_mono->width;
		m_out_mono.height = opencv_img_send_mono->height;

		// opencv_img_send(cv�`��p) -> m_out.pixels[0]
		memcpy((void *)&(m_out.pixels[0]), opencv_img_send -> imageData, len);
		memcpy((void *)&(m_out_mono.pixels[0]), opencv_img_send_mono -> imageData, len_mono);

		m_outOut.write();
		m_out_monoOut.write();
	}

	m_centerX.data = centerX;
	cout << "center_x: " << m_centerX.data << endl;
	m_centerXOut.write();

	m_centerY.data = centerY;
	cout << "center_y: " << m_centerY.data << endl;
	m_centerYOut.write();

	m_dir.data = dir;
	cout << "dir: " << m_dir.data << endl;
	m_dirOut.write();

	static coil::TimeValue tm_pre;
	static int count = 0;

	if (count > 100)
	{
		count = 0;
		coil::TimeValue tm;
		tm = coil::gettimeofday();
		double sec(tm - tm_pre);

		if (sec > 1.0 && sec < 1000.0)
		{
			std::cout << 100.0/sec << " [FPS]" << std::endl;
		}
		tm_pre = tm;
	}
	++count;

	return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t art::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t art::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t art::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t art::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t art::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

// ============================================================================
//	Functions
// ============================================================================

// cparam_name Configuration Parameter changed
bool art::cfgCheckCparamName(void)
{
	if( 0 != strcmp(cparam_name.c_str(), cfg_cparam_name.c_str()) ) 
	{
		ARMainLoopStopFlag = TRUE;
		arUtilSleep(100);

		cparam_name = cfg_cparam_name;

		if ( arParamLoad( cparam_name.c_str(), 1, &wparam ) < 0 ) 
		{
			if(paramInitFlag == FALSE)
			{
				return RTC::RTC_ERROR;
			}
		}

		arParamChangeSize( &wparam, wparam.xsize, wparam.ysize, &cparam );
		arInitCparam( &cparam );

		arParamDisp( &cparam );

		ARMainLoopStopFlag = FALSE;
		paramInitFlag = TRUE;

		return true;
	}
	return false;
}

// patt_name Configuration Parameter changed
bool art::cfgCheckPattName(void)
{	
	if( 0 != strcmp(patt_name.c_str(), cfg_patt_name.c_str()) )
	{
		ARMainLoopStopFlag = TRUE;
		arUtilSleep(100);

		patt_name = cfg_patt_name;

		arFreePatt(patt_id);
		patt_id = arLoadPatt(patt_name.c_str());

		ARMainLoopStopFlag = FALSE;

		return true;
	}
	return false;
}

// thresh Configuration Parameter changed
bool art::cfgCheckThresh(void)
{
	if( thresh != cfg_thresh ) 
	{
		thresh = cfg_thresh;

		return true;
	}

	return false;
}

int activeWaitLoop(int argc, char **argv)
{
	for(;;)
	{
		if(paramInitFlag == TRUE)
		{
			argInit( &cparam, 1.0, 0, 0, 0, 0 );

			glewInit();
			InitTexture();
			InitRenderbuffer();
			InitFramebuffer();

			// �e�N�X�`���̍쐬
			setupTexture1();
			setupTexture2();
			setupTexture3();

			// �f�B�X�v���C�E���X�g�̍쐬
			makeDisplayList1();
			makeDisplayList2();
			makeDisplayList3();

			glutDisplayFunc( Display );
			glutIdleFunc(AR_MainLoop);

			glutMainLoop();
		}
	}
}


//===========================================================================
// ���C�����[�v�֐�
//===========================================================================
void Display(void)
{
	glutHideWindow();
	AR_MainLoop();
}

void AR_MainLoop(void)
{
	if(ARMainLoopStopFlag == TRUE)
	{
		return;
	}

	if ( ar_image == NULL ) 
	{
		arUtilSleep(2);
		return;
	}

	static int		isFirst = 1;	// ����t���O
	ARMarkerInfo	*marker_info;
	int				marker_num;
	int				j, k, i;

	// Framebuffer�̐ݒ�
	glBindFramebufferEXT( GL_FRAMEBUFFER_EXT, framebuffer_name );

	// clear buffer
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	// ---- 1) ar_image(2D camera image) -> buffer  ----
	// �J�����摜�̕`��
	argDrawMode2D();
	argDispImage( ar_image, 0, 0 );
	

	// ---- 2) ar_image(2D camera image) -> �p�^�[���F�� -> 3D object -> buffer ----
	// �}�[�J�̌��o�ƔF��
	if ( arDetectMarker( ar_image, thresh, &marker_info, &marker_num ) < 0 ) 
	{
		return;
	}

	// �}�[�J�̐M���x�̔�r
	k = -1;
	for( j = 0; j < marker_num; j++ ) 
	{
		if ( patt_id == marker_info[j].id ) 
		{
			if ( k == -1 )
			{
				k = j;
			}
			else if ( marker_info[k].cf < marker_info[j].cf ) 
			{
				k = j;
			}
		}
	}

	if ( k != -1 ) 
	{
		// �}�[�J�̈ʒu�E�p���i���W�ϊ��s��j�̌v�Z
		if ( isFirst ) 
		{
			arGetTransMat( &marker_info[k], patt_center, patt_width, patt_trans );
		} 
		else 
		{
			// CG�̕\�������艻����
			arGetTransMatCont( &marker_info[k], patt_trans, patt_center, patt_width, patt_trans );
		}
		isFirst = 0;	// ����t���O������

		centerX = marker_info[k].pos[0];
		centerY = marker_info[k].pos[1];
		dir = marker_info[k].dir;

		if (frag == "all")
		{
				/* �e�N�X�`���̍쐬 */
				setupTexture1();
				setupTexture2();
				setupTexture3();

				/* �f�B�X�v���C�E���X�g�̍쐬 */
				makeDisplayList1();
				makeDisplayList2();
				makeDisplayList3();

				frag = "0";
		}

		else if (frag == "1")
		{
			f1 = "Texture\\setu.bmp";
			strcpy(file1, f1.c_str());

			setupTexture1();
			makeDisplayList1();

			frag = "0";
		}

		else if (frag == "2")
		{
			f2 = "Texture\\setu.bmp";
			strcpy(file2, f2.c_str());

			setupTexture2();
			makeDisplayList2();

			frag = "0";
		}

		else if (frag == "3")
		{
			f3 = "Texture\\setu.bmp";
			strcpy(file3, f3.c_str());

			setupTexture3();
			makeDisplayList3();

			frag = "0";
		}

		draw1();
		draw2();
		draw3();
	}

	glReadPixels(0, 0, m_in_width, m_in_height, GL_RGB, GL_UNSIGNED_BYTE, 
		opencv_img_send_tmp->imageData);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );


	// OutPort2_mono_debug_mode
	argDrawMode2D();
	argDispImage( arImage, 0, 0);

	if ( k != -1 ) 
	{
		glColor3f( 1.0, 0.0, 0.0 );
		glLineWidth( 3.0 );
		for( i = 0; i < marker_num; i++ ) 
		{
			if( marker_info[i].id < 0 ) 
				continue;
			argDrawSquare( marker_info[i].vertex, 0, 0 );
		}
		glLineWidth( 1.0 );
	}

	glReadPixels(0, 0, m_in_width, m_in_height, GL_RGB, GL_UNSIGNED_BYTE, 
		opencv_img_send_mono_tmp->imageData);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
}

//------------------------------------------------------------
//�@3�����I�u�W�F�N�g�̕`�揈��
//------------------------------------------------------------
void draw1( void )
{
	double	gl_para[16];	// ARToolkit->OpenGL�ϊ��s��

	/* 3�����I�u�W�F�N�g�̕`�揀�� */
	argDrawMode3D();
	argDraw3dCamera(0, 0);

	/* �e�N�X�`���}�b�s���O */
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

	/* �B�ʏ��� */
	glClearDepth(1.0);				// �f�v�X�E�o�b�t�@�̏����l
	glClear(GL_DEPTH_BUFFER_BIT);	// �f�v�X�E�o�b�t�@�̏�����
	glEnable(GL_DEPTH_TEST);		// �B�ʏ����E�L��
	glDepthFunc(GL_LEQUAL);			// �f�v�X�E�e�X�g

	/* ���W�ϊ��s��̓ǂݍ��� */
	argConvGlpara(patt_trans, gl_para);		// ARToolkit -> OpenGL
	glMatrixMode(GL_MODELVIEW);				// �s��ϊ����[�h�E���f���r���[
	glLoadMatrixd(gl_para);					// �ǂݍ��ލs����w��

	/* ���C�e�B���O */
	setupLighting();		// ���C�g�̒�`
	glEnable(GL_LIGHTING);	// ���C�e�B���O�E�L��
	glEnable(GL_LIGHT0);	// ���C�g0�E�I��
	glEnable(GL_LIGHT1);	// ���C�g1�E�I��

	/* �f�B�X�v���C�E���X�g���g���ăI�u�W�F�N�g��`�� */
	glCallList(listid1);

	/* �I������ */
	glDisable(GL_LIGHTING);		// ���C�e�B���O�E����
	glDisable(GL_DEPTH_TEST);	// �f�v�X�E�e�X�g�E����
}
//------------------------------------------------------------
//�@3�����I�u�W�F�N�g�̕`�揈��
//------------------------------------------------------------
void draw2( void )
{
	double	gl_para[16];	// ARToolkit->OpenGL�ϊ��s��

	/* 3�����I�u�W�F�N�g�̕`�揀�� */
	argDrawMode3D();
	argDraw3dCamera(0, 0);

	/* �e�N�X�`���}�b�s���O */
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

	/* �B�ʏ��� */
	glClearDepth(1.0);				// �f�v�X�E�o�b�t�@�̏����l
	glClear(GL_DEPTH_BUFFER_BIT);	// �f�v�X�E�o�b�t�@�̏�����
	glEnable(GL_DEPTH_TEST);		// �B�ʏ����E�L��
	glDepthFunc(GL_LEQUAL);			// �f�v�X�E�e�X�g

	/* ���W�ϊ��s��̓ǂݍ��� */
	argConvGlpara(patt_trans, gl_para);		// ARToolkit -> OpenGL
	glMatrixMode(GL_MODELVIEW);				// �s��ϊ����[�h�E���f���r���[
	glLoadMatrixd(gl_para);					// �ǂݍ��ލs����w��

	/* ���C�e�B���O */
	setupLighting();		// ���C�g�̒�`
	glEnable(GL_LIGHTING);	// ���C�e�B���O�E�L��
	glEnable(GL_LIGHT0);	// ���C�g0�E�I��
	glEnable(GL_LIGHT1);	// ���C�g1�E�I��

	/* �f�B�X�v���C�E���X�g���g���ăI�u�W�F�N�g��`�� */
	glCallList(listid2);

	/* �I������ */
	glDisable(GL_LIGHTING);		// ���C�e�B���O�E����
	glDisable(GL_DEPTH_TEST);	// �f�v�X�E�e�X�g�E����
}
//------------------------------------------------------------
//�@3�����I�u�W�F�N�g�̕`�揈��
//------------------------------------------------------------
void draw3( void )
{
	double	gl_para[16];	// ARToolkit->OpenGL�ϊ��s��

	/* 3�����I�u�W�F�N�g�̕`�揀�� */
	argDrawMode3D();
	argDraw3dCamera(0, 0);

	/* �e�N�X�`���}�b�s���O */
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

	/* �B�ʏ��� */
	glClearDepth(1.0);				// �f�v�X�E�o�b�t�@�̏����l
	glClear(GL_DEPTH_BUFFER_BIT);	// �f�v�X�E�o�b�t�@�̏�����
	glEnable(GL_DEPTH_TEST);		// �B�ʏ����E�L��
	glDepthFunc(GL_LEQUAL);			// �f�v�X�E�e�X�g

	/* ���W�ϊ��s��̓ǂݍ��� */
	argConvGlpara(patt_trans, gl_para);		// ARToolkit -> OpenGL
	glMatrixMode(GL_MODELVIEW);				// �s��ϊ����[�h�E���f���r���[
	glLoadMatrixd(gl_para);					// �ǂݍ��ލs����w��

	/* ���C�e�B���O */
	setupLighting();		// ���C�g�̒�`
	glEnable(GL_LIGHTING);	// ���C�e�B���O�E�L��
	glEnable(GL_LIGHT0);	// ���C�g0�E�I��
	glEnable(GL_LIGHT1);	// ���C�g1�E�I��

	/* �f�B�X�v���C�E���X�g���g���ăI�u�W�F�N�g��`�� */
	glCallList(listid3);

	/* �I������ */
	glDisable(GL_LIGHTING);		// ���C�e�B���O�E����
	glDisable(GL_DEPTH_TEST);	// �f�v�X�E�e�X�g�E����
}
//------------------------------------------------------------
//�@���C�e�B���O
//------------------------------------------------------------
void setupLighting(void)
{
	/* ���C�g�̒�` */
	GLfloat	lt0_position[] = {100.0, -200.0, 200.0, 0.0};	// ���C�g0�̈ʒu
	GLfloat	lt0_ambient[]  = {0.1, 0.1, 0.1, 1.0};			//          ����
	GLfloat	lt0_diffuse[]  = {0.8, 0.8, 0.8, 1.0};			//          �g�U��
	//
	GLfloat	lt1_position[] = {-100.0, 200.0, 200.0, 0.0};	// ���C�g1�̈ʒu
	GLfloat	lt1_ambient[]  = {0.1, 0.1, 0.1, 1.0};			//          ����
	GLfloat	lt1_diffuse[]  = {0.8, 0.8, 0.8, 1.0};			//          �g�U��

	/* ���C�g�̐ݒ� */
	glLightfv(GL_LIGHT0, GL_POSITION, lt0_position);
	glLightfv(GL_LIGHT0, GL_AMBIENT, lt0_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lt0_diffuse);
	//
	glLightfv(GL_LIGHT1, GL_POSITION, lt1_position);
	glLightfv(GL_LIGHT1, GL_AMBIENT, lt1_ambient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, lt1_diffuse);
}

//------------------------------------------------------------
//�@�f�B�X�v���C�E���X�g�̍쐬
//------------------------------------------------------------
void makeDisplayList1(void)
{
	/* �f�B�X�v���C�E���X�g��ID���擾 */
	listid1 = glGenLists(1);

	/* �f�B�X�v���C�E���X�g���쐬 */
	glNewList(listid1, GL_COMPILE);
		// �I�u�W�F�N�g�̕��s�ړ�
		glTranslatef(-50.0, 30.0, 0.0);
	
		// �O��	
		glBindTexture(GL_TEXTURE_2D,texname1[0]);	// 1�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, -1.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	glVertex3f(0.0, 0.0, 0.0);
			glTexCoord2d(1.0, 0.0);	glVertex3f(30.0, 0.0, 0.0);
			glTexCoord2d(1.0, 1.0);	glVertex3f(30.0, 0.0, 30.0);
			glTexCoord2d(0.0, 1.0);	glVertex3f(0.0, 0.0, 30.0);
		glEnd();
		
		// ���
		glBindTexture(GL_TEXTURE_2D,texname1[1]); 	// 2�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, 1.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(30.0, 30.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(0.0, 30.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(0.0, 30.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(30.0, 30.0, 30.0);
		glEnd();

		// ����
		glBindTexture(GL_TEXTURE_2D,texname1[2]); 	// 3�ڂ̃e�N�X�`����I��
		glNormal3f(-1.0, 0.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(0.0, 30.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(0.0, 0.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(0.0, 0.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(0.0, 30.0, 30.0);
		glEnd();

		// �E��
		glBindTexture(GL_TEXTURE_2D,texname1[3]); 	// 4�ڂ̃e�N�X�`����I��
		glNormal3f(1.0, 0.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(30.0, 0.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(30.0, 30.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(30.0, 30.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(30.0, 0.0, 30.0);
		glEnd();

		// ���
		glBindTexture(GL_TEXTURE_2D,texname1[4]); 	// 5�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, 0.0, 1.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(0.0, 0.0, 30.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(30.0, 0.0, 30.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(30.0, 30.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(0.0, 30.0, 30.0);
		glEnd();

		// ����
		glBindTexture(GL_TEXTURE_2D,texname1[5]); 	// 6�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, 0.0, -1.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(30.0, 0.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(0.0, 0.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(0.0, 30.0, 0.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(30.0, 30.0, 0.0);
		glEnd();
	glEndList();
}
//------------------------------------------------------------
//�@�f�B�X�v���C�E���X�g�̍쐬
//------------------------------------------------------------
void makeDisplayList2(void)
{
	/* �f�B�X�v���C�E���X�g��ID���擾 */
	listid2 = glGenLists(1);

	/* �f�B�X�v���C�E���X�g���쐬 */
	glNewList(listid2, GL_COMPILE);
		// �I�u�W�F�N�g�̕��s�ړ�
		glTranslatef(-15.0, 30.0, 0.0);
	
		// �O��	
		glBindTexture(GL_TEXTURE_2D,texname2[0]);	// 1�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, -1.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	glVertex3f(0.0, 0.0, 0.0);
			glTexCoord2d(1.0, 0.0);	glVertex3f(30.0, 0.0, 0.0);
			glTexCoord2d(1.0, 1.0);	glVertex3f(30.0, 0.0, 30.0);
			glTexCoord2d(0.0, 1.0);	glVertex3f(0.0, 0.0, 30.0);
		glEnd();
		
		// ���
		glBindTexture(GL_TEXTURE_2D,texname2[1]); 	// 2�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, 1.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(30.0, 30.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(0.0, 30.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(0.0, 30.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(30.0, 30.0, 30.0);
		glEnd();

		// ����
		glBindTexture(GL_TEXTURE_2D,texname2[2]); 	// 3�ڂ̃e�N�X�`����I��
		glNormal3f(-1.0, 0.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(0.0, 30.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(0.0, 0.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(0.0, 0.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(0.0, 30.0, 30.0);
		glEnd();

		// �E��
		glBindTexture(GL_TEXTURE_2D,texname2[3]); 	// 4�ڂ̃e�N�X�`����I��
		glNormal3f(1.0, 0.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(30.0, 0.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(30.0, 30.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(30.0, 30.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(30.0, 0.0, 30.0);
		glEnd();

		// ���
		glBindTexture(GL_TEXTURE_2D,texname2[4]); 	// 5�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, 0.0, 1.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(0.0, 0.0, 30.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(30.0, 0.0, 30.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(30.0, 30.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(0.0, 30.0, 30.0);
		glEnd();

		// ����
		glBindTexture(GL_TEXTURE_2D,texname2[5]); 	// 6�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, 0.0, -1.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(30.0, 0.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(0.0, 0.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(0.0, 30.0, 0.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(30.0, 30.0, 0.0);
		glEnd();
	glEndList();
}
//------------------------------------------------------------
//�@�f�B�X�v���C�E���X�g�̍쐬
//------------------------------------------------------------
void makeDisplayList3(void)
{
	/* �f�B�X�v���C�E���X�g��ID���擾 */
	listid3 = glGenLists(1);

	/* �f�B�X�v���C�E���X�g���쐬 */
	glNewList(listid3, GL_COMPILE);
		// �I�u�W�F�N�g�̕��s�ړ�
		glTranslatef(20.0, 30.0, 0.0);
	
		// �O��	
		glBindTexture(GL_TEXTURE_2D,texname3[0]);	// 1�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, -1.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	glVertex3f(0.0, 0.0, 0.0);
			glTexCoord2d(1.0, 0.0);	glVertex3f(30.0, 0.0, 0.0);
			glTexCoord2d(1.0, 1.0);	glVertex3f(30.0, 0.0, 30.0);
			glTexCoord2d(0.0, 1.0);	glVertex3f(0.0, 0.0, 30.0);
		glEnd();
		
		// ���
		glBindTexture(GL_TEXTURE_2D,texname3[1]); 	// 2�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, 1.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(30.0, 30.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(0.0, 30.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(0.0, 30.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(30.0, 30.0, 30.0);
		glEnd();

		// ����
		glBindTexture(GL_TEXTURE_2D,texname3[2]); 	// 3�ڂ̃e�N�X�`����I��
		glNormal3f(-1.0, 0.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(0.0, 30.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(0.0, 0.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(0.0, 0.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(0.0, 30.0, 30.0);
		glEnd();

		// �E��
		glBindTexture(GL_TEXTURE_2D,texname3[3]); 	// 4�ڂ̃e�N�X�`����I��
		glNormal3f(1.0, 0.0, 0.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(30.0, 0.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(30.0, 30.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(30.0, 30.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(30.0, 0.0, 30.0);
		glEnd();

		// ���
		glBindTexture(GL_TEXTURE_2D,texname3[4]); 	// 5�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, 0.0, 1.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(0.0, 0.0, 30.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(30.0, 0.0, 30.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(30.0, 30.0, 30.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(0.0, 30.0, 30.0);
		glEnd();

		// ����
		glBindTexture(GL_TEXTURE_2D,texname3[5]); 	// 6�ڂ̃e�N�X�`����I��
		glNormal3f(0.0, 0.0, -1.0);
		glBegin(GL_POLYGON);
			glTexCoord2d(0.0, 0.0);	 glVertex3f(30.0, 0.0, 0.0);
			glTexCoord2d(1.0, 0.0);	 glVertex3f(0.0, 0.0, 0.0);
			glTexCoord2d(1.0, 1.0);	 glVertex3f(0.0, 30.0, 0.0);
			glTexCoord2d(0.0, 1.0);	 glVertex3f(30.0, 30.0, 0.0);
		glEnd();
	glEndList();
}
//---------------------------------------------------------------------------
// �e�N�X�`���̍쐬
//---------------------------------------------------------------------------
void setupTexture1(void)
{
	int		h = 128;			// �C���[�W�̍���
	int		w = 128;			// �C���[�W�̕�
	int		i,j;				// ���[�v�J�E���^

	/* �s�N�Z���i�[�t�H�[�}�b�g */
	glPixelStorei(GL_UNPACK_ALIGNMENT,4);

	/* �e�N�X�`���I�u�W�F�N�g�̍쐬 */
	glGenTextures(6,texname1);

	/* 1�߂̉摜 */
	loadBmp(file1,dat);

	//--�e�N�X�`���̐ݒ�
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];					// R�l
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];					// G�l
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];					// B�l
			teximg[j][i][3]=(GLubyte)255;								// �A���t�@�l
		}
	}
	
	//--�e�N�X�`���I�u�W�F�N�g�̍쐬
	glBindTexture(GL_TEXTURE_2D,texname1[0]);							// �o�C���h
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);	// �g����@
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);	// �k�����@
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);						// 2�����e�N�X�`���̒�`

	/* 2�߂̉摜 */
//	loadBmp(file1,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname1[1]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 3�߂̉摜 */
//	loadBmp(file1,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname1[2]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 4�߂̉摜 */
//	loadBmp(file1,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname1[3]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 5�߂̉摜 */
//	loadBmp(file1,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname1[4]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 6�߂̉摜 */
//	loadBmp(file1,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname1[5]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);
}
//---------------------------------------------------------------------------
// �e�N�X�`���̍쐬
//---------------------------------------------------------------------------
void setupTexture2(void)
{
	int		h = 128;			// �C���[�W�̍���
	int		w = 128;			// �C���[�W�̕�
	int		i,j;				// ���[�v�J�E���^

	/* �s�N�Z���i�[�t�H�[�}�b�g */
	glPixelStorei(GL_UNPACK_ALIGNMENT,4);

	/* �e�N�X�`���I�u�W�F�N�g�̍쐬 */
	glGenTextures(6,texname2);

	/* 1�߂̉摜 */
	loadBmp(file2,dat);

	//--�e�N�X�`���̐ݒ�
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];					// R�l
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];					// G�l
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];					// B�l
			teximg[j][i][3]=(GLubyte)255;								// �A���t�@�l
		}
	}
	
	//--�e�N�X�`���I�u�W�F�N�g�̍쐬
	glBindTexture(GL_TEXTURE_2D,texname2[0]);							// �o�C���h
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);	// �g����@
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);	// �k�����@
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);						// 2�����e�N�X�`���̒�`

	/* 2�߂̉摜 */
//	loadBmp(file2,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname2[1]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 3�߂̉摜 */
//	loadBmp(file2,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname2[2]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 4�߂̉摜 */
//	loadBmp(file2,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname2[3]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 5�߂̉摜 */
//	loadBmp(file2,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname2[4]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 6�߂̉摜 */
//	loadBmp(file2,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname2[5]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);
}
//---------------------------------------------------------------------------
// �e�N�X�`���̍쐬
//---------------------------------------------------------------------------
void setupTexture3(void)
{
	int		h = 128;			// �C���[�W�̍���
	int		w = 128;			// �C���[�W�̕�
	int		i,j;				// ���[�v�J�E���^

	/* �s�N�Z���i�[�t�H�[�}�b�g */
	glPixelStorei(GL_UNPACK_ALIGNMENT,4);

	/* �e�N�X�`���I�u�W�F�N�g�̍쐬 */
	glGenTextures(6,texname3);

	/* 1�߂̉摜 */
	loadBmp(file3,dat);

	//--�e�N�X�`���̐ݒ�
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];					// R�l
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];					// G�l
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];					// B�l
			teximg[j][i][3]=(GLubyte)255;								// �A���t�@�l
		}
	}
	
	//--�e�N�X�`���I�u�W�F�N�g�̍쐬
	glBindTexture(GL_TEXTURE_2D,texname3[0]);							// �o�C���h
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);	// �g����@
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);	// �k�����@
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);						// 2�����e�N�X�`���̒�`

	/* 2�߂̉摜 */
//	loadBmp(file3,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname3[1]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 3�߂̉摜 */
//	loadBmp(file3,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname3[2]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 4�߂̉摜 */
//	loadBmp(file3,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname3[3]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 5�߂̉摜 */
//	loadBmp(file3,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname3[4]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);

	/* 6�߂̉摜 */
//	loadBmp(file3,dat);
	for(j=0; j<h; j++){
		for(i=0; i<w; i++){
			teximg[j][i][0]=(GLubyte)dat[j*w*3+i*3+2];
			teximg[j][i][1]=(GLubyte)dat[j*w*3+i*3+1];
			teximg[j][i][2]=(GLubyte)dat[j*w*3+i*3+0];
			teximg[j][i][3]=(GLubyte)255;
		}
	}
	glBindTexture(GL_TEXTURE_2D,texname3[5]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,
				 128,128,0,
				 GL_RGBA,GL_UNSIGNED_BYTE,teximg);
}
//---------------------------------------------------------------------------
// BMP�̓ǂݍ���
//---------------------------------------------------------------------------
void loadBmp(char *fname, unsigned char *dat)
{
	FILE			*fr;				// �t�@�C���|�C���^
	unsigned char	buf[54];			// �o�b�t�@

	/* BMP�t�@�C���E�I�[�v�� */
	fr=fopen(fname,"rb" );
	if(fr==NULL ){
		fclose(fr);
		printf("error - file cannot open !\n");
		return ;
		}

	/* BITMAPFILEHEADER, BITMAPINFOHEADER�̓ǂݍ��� */
	fread(buf,sizeof(char),54,fr);
	
	/* �s�N�Z���f�[�^�̓ǂݍ��� */
	fread(dat,sizeof(unsigned char),128*128*3,fr);
	fclose(fr);	
}

//===========================================================================
// Frame Buffer Object�̂��߂�glew�֐�
//===========================================================================

void InitTexture( void )
{
	glPixelStorei( GL_UNPACK_ALIGNMENT, 1 );
	glGenTextures( 1, &texture_name );
	glBindTexture( GL_TEXTURE_2D, texture_name );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
	glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, TEXTURE_WIDTH, TEXTURE_HEIGHT,	
		0, GL_RGB, GL_UNSIGNED_BYTE, 0 );
}

void InitRenderbuffer( void )
{
	glGenRenderbuffersEXT( 1, &renderbuffer_name );
	glBindRenderbufferEXT( GL_RENDERBUFFER_EXT, renderbuffer_name );
	glRenderbufferStorageEXT( GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT,
		RENDERBUFFER_WIDTH, RENDERBUFFER_HEIGHT );
}

void InitFramebuffer( void )
{
	glGenFramebuffersEXT( 1, &framebuffer_name );
	glBindFramebufferEXT( GL_FRAMEBUFFER_EXT, framebuffer_name );

	// Texture Object �� FBO (attach a texture to FBO color attachement point)
	glFramebufferTexture2DEXT( GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_2D, texture_name, 0 );

	// RBO �� FBO (attach a renderbuffer to depth attachment point)
	glFramebufferRenderbufferEXT( GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT,
		GL_RENDERBUFFER_EXT, renderbuffer_name );

	glBindFramebufferEXT( GL_FRAMEBUFFER_EXT, 0 );
}

extern "C"
{
 
  void artInit(RTC::Manager* manager)
  {
    coil::Properties profile(art_spec);
    manager->registerFactory(profile,
                             RTC::Create<art>,
                             RTC::Delete<art>);
  }
  
};
