// -*- C++ -*-
/*!
 * @file  QR.cpp
 * @brief QR
 * @date $Date$
 *
 * $Id$
 */

#include "QR.h"
#include <iostream>
#include <stdio.h>
#include <string.h>

unsigned char *text=NULL;
int text_size=0;

QrDecoderHandle decoder;

// Module specification
// <rtc-template block="module_spec">
static const char* qr_spec[] =
  {
    "implementation_id", "QR",
    "type_name",         "QR",
    "description",       "QR",
    "version",           "1.0.0",
    "vendor",            "ksk",
    "category",          "Category",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "0",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    // Configuration variables
    "conf.default.img_height", "480",
    "conf.default.img_width", "640",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
QR::QR(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_inIn("in", m_in),
	m_outOut("out", m_out)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
QR::~QR()
{
}



RTC::ReturnCode_t QR::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  registerInPort("in", m_inIn);
  
  // Set OutPort buffers
  registerOutPort("out", m_outOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // Bind variables and configuration variable
  bindParameter("img_height", m_img_height, "480");
  bindParameter("img_width", m_img_width, "640");
  
  // </rtc-template>
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t QR::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t QR::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t QR::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t QR::onActivated(RTC::UniqueId ec_id)
{

	m_orig_img=cvCreateImage(cvSize(m_img_width,m_img_height),IPL_DEPTH_8U,3);

	decoder=qr_decoder_open();

  return RTC::RTC_OK;
}


RTC::ReturnCode_t QR::onDeactivated(RTC::UniqueId ec_id)
{

	if(text)
        delete [] text;

    qr_decoder_close(decoder);

	if(m_orig_img)
		cvReleaseImage(&m_orig_img);

  return RTC::RTC_OK;
}


RTC::ReturnCode_t QR::onExecute(RTC::UniqueId ec_id)
{

	int nLength;
	std::string str = "";
	std::string str2 = "";

	if (!m_inIn.isNew())
    {	
		return RTC::RTC_OK;
    }
    m_inIn.read();    

    nLength = m_in.pixels.length();

    if (!(nLength > 0))
    {
        return RTC::RTC_OK;
    }

	memcpy(m_orig_img->imageData,(void *)&(m_in.pixels[0]), m_in.pixels.length());

	// QR�R�[�h�̃f�R�[�h����
	qr_decoder_set_image_buffer( decoder, m_orig_img );

	        //
            // While decoding is a failure, decrease the
            // adaptive_th_size parameter.
            // Note that the adaptive_th_size must be odd.
            //

            short sz,stat;

            for(sz = 25, stat = 0; (sz >= 3) && ((stat&QR_IMAGEREADER_DECODED) == 0); sz -= 2)
			{
                stat = qr_decoder_decode(decoder, sz);
			}

            printf("adaptive_th_size = %d, status = %04x\n", sz, stat);

            //
            // on suceed decoding, print decoded text.
            //

            QrCodeHeader header;

            if(qr_decoder_get_header(decoder, &header))
			{
                if(text_size < header.byte_size + 1)
				{
					if(text)
					{
                        delete [] text;
					}
                    
                    text_size = header.byte_size + 1;
                    text = new unsigned char[text_size];
                }

                qr_decoder_get_body(decoder, text, text_size);
//				printf("%s\n\n", text);

				for(int i = 0; i < text_size ; i++)
				{
					str = text[i];
//					std::cout << str << std::endl;
					str2 += str;
				}

				m_out.data = str2.c_str();
				std::cout << "Output: " << m_out.data << std::endl;
				m_outOut.write();
			}

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t QR::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t QR::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t QR::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t QR::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t QR::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void QRInit(RTC::Manager* manager)
  {
    coil::Properties profile(qr_spec);
    manager->registerFactory(profile,
                             RTC::Create<QR>,
                             RTC::Delete<QR>);
  }
  
};


