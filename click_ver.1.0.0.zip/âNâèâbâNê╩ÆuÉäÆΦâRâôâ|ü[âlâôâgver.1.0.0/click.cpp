// -*- C++ -*-
/*!
 * @file  click.cpp
 * @brief click
 * @date $Date$
 *
 * $Id$
 */

#include "click.h"

// Module specification
// <rtc-template block="module_spec">
static const char* click_spec[] =
  {
    "implementation_id", "click",
    "type_name",         "click",
    "description",       "click",
    "version",           "1.0.0",
    "vendor",            "Keisuke TANAKA",
    "category",          "Category",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "10",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
click::click(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_mouseIn("mouse", m_mouse),
    m_xIn("x", m_x),
    m_yIn("y", m_y),
    m_centerXIn("center_x", m_centerX),
	m_centerYIn("center_y", m_centerY),
	m_dirIn("dir", m_dir),
    m_outOut("out", m_out)

    // </rtc-template>
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  registerInPort("mouse", m_mouseIn);
  registerInPort("x", m_xIn);
  registerInPort("y", m_yIn);
  registerInPort("center_x", m_centerXIn);
  registerInPort("center_y", m_centerYIn);
  registerInPort("dir", m_dirIn);
  
  // Set OutPort buffer
  registerOutPort("out", m_outOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

}

/*!
 * @brief destructor
 */
click::~click()
{
}



RTC::ReturnCode_t click::onInitialize()
{
  return RTC::RTC_OK;
}


RTC::ReturnCode_t click::onFinalize()
{
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t click::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t click::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t click::onActivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t click::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t click::onExecute(RTC::UniqueId ec_id)
{
	int mouse;
	int x;
	int y;
	int centerX;
	int centerY;
	int dir;
	int diff;

	if (m_mouseIn.isNew())
	{
		m_mouseIn.read();
		mouse = m_mouse.data;

		if (mouse == 4)
		{
			m_dirIn.read();
			dir = m_dir.data;
			
			if (dir == 2)				// �}�[�J0�x
			{
				m_xIn.read();
				x = m_x.data;
				m_centerXIn.read();
				centerX = m_centerX.data;

				diff = x - centerX;

				if (diff < 20 && diff > -20)
				{
					m_out.data = "2";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}

				else if (diff > 20)
				{
					m_out.data = "3";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}

				else if (diff < -20)
				{
					m_out.data = "1";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}
			}
		
			else if (dir == 0)				// �}�[�J180�x
			{
				m_xIn.read();
				x = m_x.data;
				m_centerXIn.read();
				centerX = m_centerX.data;

				diff = x - centerX;

				if (diff < 20 && diff > -20)
				{
					m_out.data = "2";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}

				else if (diff > 20)
				{
					m_out.data = "1";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}

				else if (diff < -20)
				{
					m_out.data = "3";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}
			}

			else if (dir == 1)				// �}�[�J90�x
			{
				m_yIn.read();
				y = m_y.data;
				m_centerYIn.read();
				centerY = m_centerY.data;

				diff = y - centerY;

				if (diff < 20 && diff > -20)
				{
					m_out.data = "2";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}

				else if (diff > 20)
				{
					m_out.data = "3";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}

				else if (diff < -20)
				{
					m_out.data = "1";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}
			}

			else if (dir == 3)				// �}�[�J270�x
			{
				m_yIn.read();
				y = m_y.data;
				m_centerYIn.read();
				centerY = m_centerY.data;

				diff = y - centerY;

				if (diff < 20 && diff > -20)
				{
					m_out.data = "2";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}

				else if (diff > 20)
				{
					m_out.data = "1";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}

				else if (diff < -20)
				{
					m_out.data = "3";
					std::cout << m_out.data << std::endl;
					m_outOut.write();
				}
			}
		}
	}

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t click::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t click::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t click::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t click::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t click::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void clickInit(RTC::Manager* manager)
  {
    coil::Properties profile(click_spec);
    manager->registerFactory(profile,
                             RTC::Create<click>,
                             RTC::Delete<click>);
  }
  
};


