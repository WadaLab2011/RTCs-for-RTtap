// -*- C++ -*-
/*!
 * @file  GUI.cpp
 * @brief GUI
 * @date $Date$
 *
 * $Id$
 */

#include "GUI.h"
#include <iostream>
#include <string>

std::string guifrag = "0";
std::string outfrag = "0";
std::string appliance = "";
std::string ope = "";
std::string qr = "";
std::string num = "";

// Module specification
// <rtc-template block="module_spec">
static const char* gui_spec[] =
  {
    "implementation_id", "GUI",
    "type_name",         "GUI",
    "description",       "GUI",
    "version",           "1.0.0",
    "vendor",            "Keisuke TANAKA",
    "category",          "Category",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "10",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
GUI::GUI(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_qrIn("qr", m_qr),
    m_numIn("num", m_num),
    m_opeOut("ope", m_ope),
    m_updateOut("update", m_update),
	m_settingOut("setting", m_setting)

    // </rtc-template>
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  registerInPort("qr", m_qrIn);
  registerInPort("num", m_numIn);
  
  // Set OutPort buffer
  registerOutPort("ope", m_opeOut);
  registerOutPort("update", m_updateOut);
  registerOutPort("setting", m_settingOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

}

/*!
 * @brief destructor
 */
GUI::~GUI()
{
}



RTC::ReturnCode_t GUI::onInitialize()
{
	std::cout << "Lily Library, Kengo Watanabe (http://kengolab.net/) \n" << std::endl;

  return RTC::RTC_OK;
}


RTC::ReturnCode_t GUI::onFinalize()
{
	guifrag = "3";

  return RTC::RTC_OK;
}


/*
RTC::ReturnCode_t GUI::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t GUI::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t GUI::onActivated(RTC::UniqueId ec_id)
{
	guifrag = "0";
	qr = "";
	num = "";

  return RTC::RTC_OK;
}


RTC::ReturnCode_t GUI::onDeactivated(RTC::UniqueId ec_id)
{
	guifrag = "2";
	qr = "";
	num = "";

  return RTC::RTC_OK;
}

RTC::ReturnCode_t GUI::onExecute(RTC::UniqueId ec_id)
{
	std::string out = "";

	guifrag = "0";

	if (m_qrIn.isNew())
    {
		m_qrIn.read();
		qr = m_qr.data;

		std::cout << "Received: " << qr << std::endl;
	}

	if (m_numIn.isNew())
    {
		m_numIn.read();
		num = m_num.data;

		std::cout << "Received: " << num << std::endl;

		if (qr != "" && num != "")
		{
			std::cout << qr << "." << num << std::endl;
			guifrag = "1";

			m_setting.data = num.c_str();
			std::cout << "Output: " << m_setting.data << std::endl;
			m_settingOut.write();
		}
	}

	if (outfrag == "1")				// �X�V
	{
		out = "";
		out += qr;
		out += ".";
		out += num;
		out += ".";
		out += appliance;

		m_update.data = out.c_str();
		std::cout << "Output: " << m_update.data << std::endl;
		m_updateOut.write();

		out = "";
		out += qr;
		out += ".";
		out += num;
		out += ".";
		out += ope;

		m_ope.data = out.c_str();
		std::cout << "Output: " << m_ope.data << std::endl;
		m_opeOut.write();

		ope = "";
		outfrag = "0";
	}

	else if (outfrag == "2")		// ����
	{
		out = "";
		out += qr;
		out += ".";
		out += num;
		out += ".";
		out += ope;

		m_ope.data = out.c_str();
		std::cout << "Output: " << m_ope.data << std::endl;
		m_opeOut.write();

		ope = "";
		outfrag = "0";
	}

	else if (outfrag == "3")		// �ύX�Ȃ�
	{
		out = "";
		out += qr;
		out += ".";
		out += num;
		out += ".";
		out += appliance;

		m_update.data = out.c_str();
		std::cout << "Output: " << m_update.data << std::endl;
		m_updateOut.write();

		appliance = "";
		outfrag = "0";
	}

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t GUI::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t GUI::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t GUI::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t GUI::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t GUI::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void GUIInit(RTC::Manager* manager)
  {
    coil::Properties profile(gui_spec);
    manager->registerFactory(profile,
                             RTC::Create<GUI>,
                             RTC::Delete<GUI>);
  }
  
};


